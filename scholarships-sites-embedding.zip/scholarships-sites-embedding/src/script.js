// makes hamburger clickable
document.getElementById('hamburger').addEventListener('click', function() {
    document.getElementById('main-nav').classList.toggle('show');
});
